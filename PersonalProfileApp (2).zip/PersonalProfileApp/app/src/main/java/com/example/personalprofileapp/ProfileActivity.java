package com.example.personalprofileapp;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ProfileActivity extends AppCompatActivity {

    private TextView textView2;
    private TextView textView4;
    private TextView textView;
    private TextView textView3;
    private TextView textViewProfileInfo;

    private ImageView imageView;
    private Switch switchProfilePicture;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile);

        imageView = findViewById(R.id.imageView);
        textView4 = findViewById(R.id.textView6);
        textView3 = findViewById(R.id.textView3);
        textView2 = findViewById(R.id.textView2);
        textView = findViewById(R.id.textView);
        textViewProfileInfo = findViewById(R.id.textView);
        switchProfilePicture = findViewById(R.id.switch1);

        // Receive the data from Screen A
        Intent intent = getIntent();
        String userInputText = intent.getStringExtra("userInputText");
        String userInputText2 = intent.getStringExtra("userInputText2");
        boolean isChecked = intent.getBooleanExtra("isChecked", false);
        boolean isChecked2 = intent.getBooleanExtra("isChecked2", false);
        boolean isChecked3 = intent.getBooleanExtra("isChecked3", false);
        String selectedRadioButtonText = intent.getStringExtra("selectedRadioButtonText");

        //Display Profile Information
        textView2.setText("name: " + userInputText);
        textView3.setText("Age: " + userInputText2);
        textView.setText("Hobbies: Sports?" +isChecked + "Coding?" + isChecked2 + "Hiking?" +isChecked3);
        textView4.setText("Gender: " + selectedRadioButtonText);


        //boolean isSwitchOn = switchProfilePicture.isChecked();
        //if(isSwitchOn) {
           // imageView.setVisibility(View.VISIBLE);
        //}
        //else {
          //  imageView.setVisibility(View.INVISIBLE);
        //}



        // Add logic for the switch to toggle the profile picture (you'll need to implement this part)
        switchProfilePicture.setOnCheckedChangeListener((buttonView, isCheckedY) -> {
            if (isCheckedY) {
                // Turn on profile picture
                imageView.setVisibility(View.VISIBLE);
                // Implement your logic here
            } else {
                // Turn off profile picture
                // Implement your logic here
                imageView.setVisibility(View.INVISIBLE);
            }
        });
    }
}
