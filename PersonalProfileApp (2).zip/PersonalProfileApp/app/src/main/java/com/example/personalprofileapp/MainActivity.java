package com.example.personalprofileapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.CheckBox;
import android.widget.RadioGroup;

import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {


    private EditText editText;
    private EditText editText2;
    private CheckBox checkBox;
    private CheckBox checkBox2;
    private CheckBox checkBox3;
    private RadioGroup radioGroup;
    private RadioButton radioOption1, radioOption2;
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = findViewById(R.id.EditText);
        editText2 = findViewById(R.id.EditText2);
        checkBox = findViewById(R.id.checkBox);
        checkBox2 = findViewById(R.id.checkBox2);
        checkBox3 = findViewById(R.id.checkBox3);
        radioGroup = findViewById(R.id.RadioGroup);
        radioOption1 = findViewById(R.id.radioButton);
        radioOption2 = findViewById(R.id.radioButton2);
        Button myButton = findViewById(R.id.button);

        myButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ProfileActivity.class);
                String userInputText = editText.getText().toString();
                String userInputText2 = editText2.getText().toString();


                boolean isChecked = checkBox.isChecked();
                boolean isChecked2 = checkBox2.isChecked();
                boolean isChecked3 = checkBox3.isChecked();
                int SelectedRadioButtonID = radioGroup.getCheckedRadioButtonId();
                String selectedRadioButtonText = "undefined";

                //if male is checked say male, if female is checked and male is not checked say female otherwise say undefined
                if(radioOption1.isChecked() && !radioOption2.isChecked()){
                    selectedRadioButtonText = "Male";
                } else if (radioOption2.isChecked() && !radioOption1.isChecked()) {
                    selectedRadioButtonText = "Female";
                }
                else
                    selectedRadioButtonText = "undefined";

               // if (SelectedRadioButtonID != 1) {
                   // RadioButton selectedRadioButton = findViewById(SelectedRadioButtonID);
                   // selectedRadioButtonText = radioOption2.getText().toString();
               // }


                // Create an Intent to pass data to Screen B
                intent.putExtra("userInputText", userInputText);
                intent.putExtra("userInputText2", userInputText2);
                intent.putExtra("isChecked", isChecked);
                intent.putExtra("isChecked2",isChecked2);
                intent.putExtra("isChecked3",isChecked3);
                intent.putExtra("selectedRadioButtonText", selectedRadioButtonText);


                startActivity(intent);

            }
        });


    }

    public void loadConstraintLayout(View v){
        setContentView(R.layout.activity_main);
    }

    public void loadProfile(View v){
        setContentView(R.layout.profile);
    }

}