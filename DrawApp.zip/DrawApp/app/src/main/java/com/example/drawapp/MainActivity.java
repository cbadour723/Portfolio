package com.example.drawapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    private ImageView drawingCanvas;
    private Button drawRectangleButton;
    private Button drawCircleButton;
    private Button paintRectangleButton;
    private Button paintCircleButton;
    private Button clearButton;
    private Bitmap bitmap;
    private Canvas canvas;
    private Paint paint;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements
        drawingCanvas = findViewById(R.id.drawingCanvas);
        drawRectangleButton = findViewById(R.id.buttonDrawRectangle);
        drawCircleButton = findViewById(R.id.buttonDrawCircle);
        paintRectangleButton = findViewById(R.id.buttonPaintRectangle);
        paintCircleButton = findViewById(R.id.buttonPaintCircle);
        clearButton = findViewById(R.id.buttonClear);

        // Initialize Bitmap and Canvas
        bitmap = Bitmap.createBitmap(1000, 1000, Bitmap.Config.ARGB_8888);
        canvas = new Canvas(bitmap);
        drawingCanvas.setImageBitmap(bitmap);

        // Initialize Paint
        paint = new Paint();
        paint.setColor(Color.BLACK);
        paint.setStrokeWidth(5);
        paint.setStyle(Paint.Style.STROKE);

        // Set click listeners for buttons and implement drawing logic
        drawRectangleButton.setOnClickListener(v -> {
            // Implement logic to draw a rectangle on the canvas
            canvas.drawRect(200, 200,500,500, paint);
        });
        drawCircleButton.setOnClickListener(v -> {
            canvas.drawCircle(400,250,100,paint);
        });

        // Implement click listeners for other buttons
        paintRectangleButton.setOnClickListener(v -> {
            // Set the paint color for drawing rectangles
            paint.setColor(Color.RED); // Example: Red color
        });
        paintCircleButton.setOnClickListener(v -> {
            // Set the paint color for drawing rectangles
            paint.setColor(Color.BLUE); // Example: Red color
        });

        clearButton.setOnClickListener(v -> {
            // Implement logic to clear the canvas
            canvas.drawColor(Color.WHITE); // Clear the canvas with a white background
            drawingCanvas.invalidate(); // Refresh the canvas
        });
    }

    // Implement methods to handle drawing and clearing logic

}
