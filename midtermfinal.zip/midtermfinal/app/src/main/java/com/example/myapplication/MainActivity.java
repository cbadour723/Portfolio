package com.example.myapplication;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.CityInformationDisplayActivity;
import com.example.myapplication.DatabaseHelper;
import com.example.myapplication.R;

public class MainActivity extends AppCompatActivity {

    DatabaseHelper dbHelper;
    SQLiteDatabase db;
    EditText cityInput;
    EditText TitleInput;
    Button fetchInfoBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);
        db = dbHelper.getReadableDatabase();

        TitleInput = findViewById(R.id.TitleInput);
        fetchInfoBtn = findViewById(R.id.fetchInfoBtn);


    //on click fetch info button activate database and search for book
        fetchInfoBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String titleName = TitleInput.getText().toString();
                Cursor cursor = db.rawQuery("SELECT * FROM " + DatabaseHelper.TABLE_NAME + " WHERE title=?", new String[]{titleName});

                if (cursor != null && cursor.moveToFirst()) {
                    Intent intent = new Intent(MainActivity.this, CityInformationDisplayActivity.class);

                    int titleColumnIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_Title);
                    int authorColumnIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_Author);
                    int genreColumnIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_Genre);


                    if (titleColumnIndex != -1) {
                        intent.putExtra("title", cursor.getString(titleColumnIndex));
                    }
                    if (authorColumnIndex != -1) {
                        intent.putExtra("author", cursor.getString(authorColumnIndex));
                    }
                    if (genreColumnIndex != -1) {
                        intent.putExtra("genre", cursor.getString(genreColumnIndex));
                    }

                    startActivity(intent);
                }

                cursor.close();

                // if database is not activated and button does not work change to book not found
               TitleInput.setText("Book not Found");


           //     cursor.close();
            }
        });
    }
}
