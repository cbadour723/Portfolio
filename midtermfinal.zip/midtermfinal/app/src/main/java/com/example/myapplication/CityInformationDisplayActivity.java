package com.example.myapplication;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.R;


//this class displays book information
public class CityInformationDisplayActivity extends AppCompatActivity {

    TextView TitleTextView, AuthorTextView, GenreTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_city_information_display);

        TitleTextView = findViewById(R.id.TitleTextView);
        AuthorTextView = findViewById(R.id.AuthorTextView);
        GenreTextView = findViewById(R.id.GenreTextView);


        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            TitleTextView.setText(extras.getString("title"));
            AuthorTextView.setText(extras.getString("author"));
            GenreTextView.setText(extras.getString("genre"));
        }
    }
}
