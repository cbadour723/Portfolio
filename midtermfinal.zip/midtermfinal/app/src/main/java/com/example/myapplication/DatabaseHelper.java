package com.example.myapplication;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "bookinfo.db";
    private static final int DATABASE_VERSION = 1;
    public static final String TABLE_NAME = "BookInfo";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_Title = "title";
    public static final String COLUMN_Author = "author";
    public static final String COLUMN_Genre = "genre";


    private static final String TABLE_CREATE =
            "CREATE TABLE " + TABLE_NAME + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_Title + " TEXT, " +
                    COLUMN_Author + " TEXT, " +
                    COLUMN_Genre + " TEXT);";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    //
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_CREATE);
        // Insert sample data (this would ideally come from an external source or API)
        db.execSQL("INSERT INTO " + TABLE_NAME + " (title, author, genre) VALUES ('The Great Gatsby', 'F. Scott Fitzgerald', 'Novel')");
        db.execSQL("INSERT INTO " + TABLE_NAME + " (title, author, genre) VALUES ('To Kill a MockingBird', 'Harper Lee', 'Novel')");
        db.execSQL("INSERT INTO " + TABLE_NAME + " (title, author, genre) VALUES ('1984', 'George Orwell', 'Dystopian')");
        db.execSQL("INSERT INTO " + TABLE_NAME + " (title, author, genre) VALUES ('To Kill a Mockingbird', 'Harper Lee', 'Novel')");
        //... add more cities as needed
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }
}
