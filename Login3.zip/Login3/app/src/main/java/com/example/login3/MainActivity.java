package com.example.login3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText usernameEditText, passwordEditText, enteredusername;
    private Button loginButton, registerButton;
    private databasehelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usernameEditText = findViewById(R.id.editText);
        passwordEditText = findViewById(R.id.editText2);
        enteredusername = findViewById(R.id.editText3);
        loginButton = findViewById(R.id.button2);
        registerButton = findViewById(R.id.button1);

        dbHelper = new databasehelper(this);

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                long userId = dbHelper.addUser(username, password);

                if (userId != -1) {
                    // Registration successful, optionally display a success message
                } else {
                    // Show an error message for registration failure
                }
            }
        });

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = enteredusername.getText().toString();
                String password = passwordEditText.getText().toString();
                String username1 = usernameEditText.getText().toString();


                if (dbHelper.checkUser(username, password)) {
                    Intent intent = new Intent(MainActivity.this, WelcomeActivity.class);
                    intent.putExtra("username", username);
                    startActivity(intent);
                } else {
                    // Show an error message for invalid credentials
                }
            }
        });


    }
}