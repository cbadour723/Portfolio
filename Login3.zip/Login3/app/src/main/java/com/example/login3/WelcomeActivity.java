package com.example.login3;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class WelcomeActivity extends AppCompatActivity {
    private TextView welcomeMessageTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcome);

        welcomeMessageTextView = findViewById(R.id.textView);

        Intent intent = getIntent();
        String username = intent.getStringExtra("username");

        if (username != null) {
            welcomeMessageTextView.setText("Welcome, " + username + "!");
        }
    }
}

